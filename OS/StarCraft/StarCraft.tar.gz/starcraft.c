#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>

int minerals = 5000;
int acq_minerals = 0;

pthread_mutex_t mutex;

void work(void *w){
  int id = (int)w;
  printf("SCV %d is mining\n", id);
  pthread_mutex_lock(&mutex);
    acq_minerals += 8;
    minerals -= 8;
  pthread_mutex_unlock(&mutex);
  printf("SCV %d is transporting minerals\n", id);
  sleep(2);
  printf("SCV %d delivered minerals to Command center 1\n", id);
}

int main(){
  int workers = 5;
  int soldiers = 0;
  int com_center = 1;
  int i;
  pthread_mutex_init(&mutex, NULL);
  pthread_t worker_threads[workers];
  for(i = 0; i < workers; i++){
      if(pthread_create(&worker_threads[i], NULL, work, (void*)i)){
        perror("Error while creating worker");
      }
  }

  for(i = 0; i < workers; i++){
    pthread_join(worker_threads[i], NULL);
  }
  char s;
  while(1){
    scanf("%s\n", &s);
    if(s == 'm'){
      if (acq_minerals < 50){
        printf("Not enough minerals\n");
      } else {
        pthread_mutex_lock(&mutex);
        acq_minerals -= 50;
        pthread_mutex_unlock(&mutex);
        sleep(1000);
        soldiers += 1;

        printf("You want a piece of me, boy?\n");
      }
    } else {
      printf("No such command\n");
    }
    if (soldiers == 8){
      break;
    }
  }

  printf("Starting minerals: 5000\n");
  printf("Remaining minerals: %d\n", minerals);
  printf("Collected minerals: %d\n", acq_minerals);
  pthread_mutex_destroy(&mutex);

  return 0;
}
